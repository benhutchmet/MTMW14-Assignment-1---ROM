# README.md for assignment 1 ROM

Code for assignment 1, exploring the ROM.

Contains: Project_1_30832950.ipynb, Functions.ipynb and Stability.ipynb

Project_1_30832950.ipynb is essentially the 'main' file and is used to run the schemes.

Functions.ipynb contains the functions for executing the tasks in Project_1_30832950.ipynb

Stability.ipynb contains code from Ben Hutchins and Prof. Pier Luigi Vidale which show the stability of different time-stepping schemes.